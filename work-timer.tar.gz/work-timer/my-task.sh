#!/bin/bash
# 
# default config.
###############################################################
TIMER_SET=23:01
root_dir=/home/android
build_prj=v3991
build_type=userdebug
prj_path=$root_dir/work/prj/3991/debug/
###############################################################

if [ -n "$1" ] ; then
    build_prj=$1
fi

if [ -n "$2" ] ; then
    build_type=$2
fi

if [ -n "$3" ] ; then
   prj_path=$3
fi

if [ ! -d $root_dir/build-log ] ; then
   mkdir -p $root_dir/build-log
fi

rm -rf $root_dir/build-log/everyday-build-$build_prj-$build_type.log 
echo "$build_prj | $build_type |$prj_path" >> $root_dir/build-log/everyday-build-$build_prj-$build_type.log

cd $prj_path
rm -rf baseline/.git
rm -rf baseline/kernel-3.18
repo sync -j24 2>&1 |tee $root_dir/build-log/everyday-build-$build_prj-$build_type.log &&
cd baseline &&

#########################################################################
# p7701/p7705
if [ "$build_prj" = "p7701" ]; then
    echo "start build $build_prj..."
    source tinno_all_compile.sh $build_prj $build_type
    exit 0
else
if [ "$build_prj" = "p7705" ]; then
    echo "start build $build_prj..."
    source tinno_all_compile_jenkins_sign.sh $build_prj $build_type
    exit 0
fi
fi
#########################################################################

# other mtk prj.
source build/envsetup.sh &&
source mbldenv.sh &&
lunch full_$build_prj-$build_type >> $root_dir/build-log/everyday-build-$build_prj-$build_type.log &&
echo "start make... " >> $root_dir/build-log/everyday-build-$build_prj-$build_type.log &&
make clean &&
make BUILD_MYOS=yes -j24 2>&1 |tee build.log && 
rm -rf $(find $root_dir/sw_release/$build_prj-trunk-$build_type -name "*.zip" |sort |head -1) &&
$root_dir/work/script/release.sh &&
echo "--end-- " >> $root_dir/build-log/everyday-build-$build_prj-$build_type.log
#########################################################################



