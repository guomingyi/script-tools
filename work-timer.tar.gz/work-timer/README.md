# fury

# address
https://github.com/guomingyi/work_timerd.git

# Username & password:
guomingyi
**********


# Push code:

git add .;
git commit -am "<xxx>";
git remote add origin https://github.com/guomingyi/work_timerd.git
git pull origin master;   
git push -u origin master;


# Code download:

git clone https://github.com/guomingyi/work_timerd.git
git pull origin master;  

